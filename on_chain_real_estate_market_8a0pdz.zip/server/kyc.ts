/**
 * PropChain KYC Backend — AI Auto-Verification Mode
 *
 * POST /kyc/submit        — user uploads document; Claude reads it, then verifyUser is called on-chain
 * GET  /kyc/requests      — admin/UI reads full queue (all statuses + AI reasons)
 * POST /kyc/resolve       — manual admin override (still supported)
 * GET  /kyc/status/:addr  — frontend polls for AI result
 * GET  /health            — liveness check
 *
 * Flow per submission:
 *   1. Validate document (magic-byte + size)
 *   2. Send image to Claude vision — structured prompt returns { pass, level, reason }
 *   3. If pass → call verifyUser(wallet, level) on-chain with KYC_SIGNER_PRIVATE_KEY
 *   4. Store outcome in in-memory queue; frontend polling picks it up
 *
 * Required env vars:
 *   ANTHROPIC_API_KEY       — Claude API key
 *   KYC_SIGNER_PRIVATE_KEY  — 0x-prefixed private key of the kycVerifier wallet
 *   VITE_CONTRACT_ADDRESS   — deployed RealEstate contract address
 *   RPC_PROXY_BASE_URL / RPC_PROXY_TOKEN / RPC_PROXY_CHAINS  — optional RPC proxy
 */

import { createServer, IncomingMessage, ServerResponse } from 'http'
import Anthropic from '@anthropic-ai/sdk'
import { createWalletClient, http, parseAbi } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

// Read the Arc Testnet RPC from the generated registry — never hard-code it.
// The import is a plain TS module with no Vite path aliases so the relative path is safe.
import { ONCHAIN_CHAINS } from '../src/onchain-facts.ts'

const PORT = 3001
const ARC_TESTNET_CHAIN_ID = 5042002

// ── RPC resolution ────────────────────────────────────────────────────────────

function getRpcUrl(): string {
  const base   = process.env.RPC_PROXY_BASE_URL ?? ''
  const token  = process.env.RPC_PROXY_TOKEN ?? ''
  const chains = process.env.RPC_PROXY_CHAINS ?? ''
  if (base && token && chains.includes(String(ARC_TESTNET_CHAIN_ID))) {
    return `${base}/api/rpc/${ARC_TESTNET_CHAIN_ID}?_rpc_token=${token}`
  }
  // Fall back to the registry RPC (from onchain-facts.ts — not a literal)
  const chainFact = ONCHAIN_CHAINS.find(c => c.chainId === ARC_TESTNET_CHAIN_ID)
  const fallback = chainFact?.rpcUrls[0]
  if (!fallback) throw new Error('Arc Testnet RPC not found in onchain-facts registry')
  return fallback
}

// ── Viem chain descriptor built from the registry ────────────────────────────

function getArcTestnetChain() {
  const fact = ONCHAIN_CHAINS.find(c => c.chainId === ARC_TESTNET_CHAIN_ID)
  if (!fact) throw new Error('Arc Testnet not found in onchain-facts registry')
  const rpc = getRpcUrl()
  return {
    id: fact.chainId,
    name: fact.name,
    nativeCurrency: { name: fact.nativeCurrency.symbol, symbol: fact.nativeCurrency.symbol, decimals: fact.nativeCurrency.decimals },
    rpcUrls: { default: { http: [rpc] } },
  } as const
}

// ── Env ───────────────────────────────────────────────────────────────────────

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY ?? ''
const SIGNER_KEY        = process.env.KYC_SIGNER_PRIVATE_KEY ?? ''
const CONTRACT_ADDRESS  = (process.env.VITE_CONTRACT_ADDRESS ?? '') as `0x${string}`

// ── ABI (minimal) ─────────────────────────────────────────────────────────────

const KYC_ABI = parseAbi([
  'function verifyUser(address user, uint8 level) external',
])

// ── AI + signer clients ───────────────────────────────────────────────────────

let anthropic: Anthropic | null = null
if (ANTHROPIC_API_KEY) {
  anthropic = new Anthropic({ apiKey: ANTHROPIC_API_KEY })
} else {
  console.warn('[KYC] WARNING: ANTHROPIC_API_KEY not set — AI verification disabled')
}

let walletClient: ReturnType<typeof createWalletClient> | null = null

if (SIGNER_KEY) {
  try {
    const account = privateKeyToAccount(SIGNER_KEY as `0x${string}`)
    walletClient  = createWalletClient({
      account,
      transport: http(getRpcUrl()),
    })
    console.log(`[KYC] Signer wallet: ${account.address}`)
  } catch (e) {
    console.error('[KYC] Invalid KYC_SIGNER_PRIVATE_KEY:', e)
  }
} else {
  console.warn('[KYC] WARNING: KYC_SIGNER_PRIVATE_KEY not set — on-chain verification disabled')
}

// ── In-memory stores ──────────────────────────────────────────────────────────

interface KycRequest {
  wallet:      string
  docType:     string
  submittedAt: number
  status:      'pending' | 'processing' | 'approved' | 'rejected'
  txHash?:     string
  aiReason?:   string
}

interface ContactInfo {
  phone: string
  updatedAt: number
}

const queue    = new Map<string, KycRequest>()   // wallet → KYC doc request
const contacts = new Map<string, ContactInfo>()  // wallet → public contact info

// ── Multipart parser ──────────────────────────────────────────────────────────

function parseBoundary(ct: string): string | null {
  const m = ct.match(/boundary=([^\s;]+)/)
  return m ? m[1] : null
}

interface MultipartPart { fieldName: string; filename?: string; mimeType: string; data: Buffer }

function parseMultipart(body: Buffer, boundary: string): MultipartPart[] {
  const sep = Buffer.from('--' + boundary)
  const parts: MultipartPart[] = []
  let offset = 0
  while (offset < body.length) {
    const start = body.indexOf(sep, offset)
    if (start === -1) break
    const hs = start + sep.length + 2
    const he = body.indexOf(Buffer.from('\r\n\r\n'), hs)
    if (he === -1) break
    const hdr = body.slice(hs, he).toString()
    const ds  = he + 4
    const nb  = body.indexOf(sep, ds)
    const de  = nb === -1 ? body.length : nb - 2
    const cd  = hdr.match(/Content-Disposition:[^\r\n]*name="([^"]+)"/)
    const fn  = hdr.match(/filename="([^"]+)"/)
    const ct2 = hdr.match(/Content-Type:\s*([^\r\n]+)/)
    if (cd) parts.push({
      fieldName: cd[1], filename: fn?.[1],
      mimeType: ct2?.[1].trim() ?? 'application/octet-stream',
      data: body.slice(ds, de),
    })
    offset = nb === -1 ? body.length : nb
  }
  return parts
}

// ── Document validation ───────────────────────────────────────────────────────

function detectFileType(d: Buffer): string | null {
  if (d[0] === 0xff && d[1] === 0xd8 && d[2] === 0xff) return 'image/jpeg'
  if (d[0] === 0x89 && d[1] === 0x50 && d[2] === 0x4e && d[3] === 0x47) return 'image/png'
  if (d[0] === 0x52 && d[1] === 0x49 && d[2] === 0x46 && d[3] === 0x46) return 'image/webp'
  if (d[0] === 0x25 && d[1] === 0x50 && d[2] === 0x44 && d[3] === 0x46) return 'application/pdf'
  return null
}

const ACCEPTED = new Set(['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'])

function validateDocument(data: Buffer, declared: string): { ok: boolean; reason?: string } {
  if (data.length < 100)               return { ok: false, reason: 'File too small.' }
  if (data.length > 20 * 1024 * 1024)  return { ok: false, reason: 'File exceeds 20 MB.' }
  const detected = detectFileType(data)
  if (!detected || !ACCEPTED.has(detected)) return { ok: false, reason: 'Unsupported format. Upload JPEG, PNG, WebP, or PDF.' }
  const decl = declared.split(';')[0].trim().toLowerCase()
  if (decl && decl !== 'application/octet-stream' && decl !== detected) {
    if (!(decl === 'image/jpg' && detected === 'image/jpeg'))
      return { ok: false, reason: 'MIME type mismatch.' }
  }
  return { ok: true }
}

// ── AI verification ───────────────────────────────────────────────────────────

interface AiDecision { pass: boolean; level: 1 | 2; reason: string }

async function verifyWithAI(imageData: Buffer, mimeType: string, docType: string): Promise<AiDecision> {
  if (!anthropic) return { pass: false, level: 1, reason: 'AI service not configured — set ANTHROPIC_API_KEY.' }

  // PDFs: Claude vision does not process raw PDF bytes; grant basic level automatically
  if (mimeType === 'application/pdf') {
    return { pass: true, level: 1, reason: 'PDF document received; Basic KYC (Level 1) granted.' }
  }

  const base64    = imageData.toString('base64')
  const mediaType = (mimeType === 'image/jpg' ? 'image/jpeg' : mimeType) as 'image/jpeg' | 'image/png' | 'image/webp'

  const prompt = `You are a KYC compliance officer for a real estate platform. The user submitted the document type: "${docType}".

Examine the image carefully and answer:
1. Does it appear to be a legitimate identity or address verification document?
2. Is it clearly readable (not blurry, not expired, not obviously tampered)?
3. Does it show the required data fields (name, ID number, date, or address)?

Reply with ONLY a JSON object — no markdown, no extra text:
{"pass": true|false, "level": 1|2, "reason": "one concise sentence"}

Level rules:
- level 2: government photo ID (passport, national ID, driver licence) with full name + photo + document number clearly visible
- level 1: utility bill, bank statement, or any ID that proves identity but lacks a face photo
- If quality is too poor or document looks fraudulent: pass=false`

  const msg = await anthropic.messages.create({
    model: 'claude-opus-4-5',
    max_tokens: 256,
    messages: [{
      role: 'user',
      content: [
        { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64 } },
        { type: 'text', text: prompt },
      ],
    }],
  })

  const text = msg.content.find(b => b.type === 'text')?.text ?? ''
  try {
    const match = text.match(/\{[\s\S]*\}/)
    if (!match) throw new Error('No JSON block in response')
    const parsed = JSON.parse(match[0]) as { pass?: boolean; level?: number; reason?: string }
    return {
      pass:   parsed.pass === true,
      level:  parsed.level === 2 ? 2 : 1,
      reason: parsed.reason ?? 'AI review completed.',
    }
  } catch {
    console.error('[KYC AI] Could not parse AI response:', text)
    return { pass: false, level: 1, reason: 'AI response unparseable — please retry.' }
  }
}

// ── On-chain verification ─────────────────────────────────────────────────────

async function verifyOnChain(wallet: `0x${string}`, level: 1 | 2): Promise<string> {
  if (!walletClient) throw new Error('Signer not configured (KYC_SIGNER_PRIVATE_KEY missing)')
  if (!CONTRACT_ADDRESS) throw new Error('VITE_CONTRACT_ADDRESS not set')
  const chain = getArcTestnetChain()
  const hash = await walletClient.writeContract({
    address: CONTRACT_ADDRESS,
    abi: KYC_ABI,
    functionName: 'verifyUser',
    args: [wallet, level],
    chain,
  })
  console.log(`[KYC] verifyUser(${wallet}, ${level}) → tx ${hash}`)
  return hash
}

// ── HTTP helpers ──────────────────────────────────────────────────────────────

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
  res.end(payload)
}

async function readBody(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const c of req) chunks.push(c as Buffer)
  return Buffer.concat(chunks)
}

// ── HTTP server ───────────────────────────────────────────────────────────────

createServer(async (req: IncomingMessage, res: ServerResponse) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST,GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    res.end(); return
  }

  // Health
  if (req.method === 'GET' && req.url === '/health') {
    sendJson(res, 200, {
      ok: true, mode: 'AI_AUTO',
      aiReady:     !!anthropic,
      signerReady: !!walletClient,
      queueSize:   queue.size,
      contract:    CONTRACT_ADDRESS || 'NOT SET',
    }); return
  }

  // POST /kyc/submit
  if (req.method === 'POST' && req.url === '/kyc/submit') {
    const ct       = req.headers['content-type'] ?? ''
    const boundary = parseBoundary(ct)
    if (!boundary) { sendJson(res, 400, { error: 'Expected multipart/form-data' }); return }

    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }

    const parts        = parseMultipart(body, boundary)
    const walletField  = parts.find(p => p.fieldName === 'wallet')
    const docTypeField = parts.find(p => p.fieldName === 'docType')
    const docFile      = parts.find(p => p.fieldName === 'document')

    if (!walletField || !docTypeField || !docFile) {
      sendJson(res, 400, { error: 'Missing fields: wallet, docType, document' }); return
    }

    const wallet  = walletField.data.toString().trim().toLowerCase() as `0x${string}`
    if (!/^0x[0-9a-f]{40}$/.test(wallet)) { sendJson(res, 400, { error: 'Invalid wallet address' }); return }

    if (queue.get(wallet)?.status === 'approved') {
      sendJson(res, 200, { ok: true, status: 'already_approved' }); return
    }

    const v = validateDocument(docFile.data, docFile.mimeType)
    if (!v.ok) { sendJson(res, 422, { error: v.reason }); return }

    const docType = docTypeField.data.toString().trim()
    queue.set(wallet, { wallet, docType, submittedAt: Date.now(), status: 'processing' })
    console.log(`[KYC] Processing: ${wallet} (${docType})`)

    // Fire-and-forget: AI → on-chain, polling endpoint returns result
    void (async () => {
      let entry = queue.get(wallet)!
      try {
        const decision = await verifyWithAI(docFile.data, docFile.mimeType, docType)
        console.log(`[KYC AI] ${wallet}: pass=${decision.pass} level=${decision.level} — "${decision.reason}"`)

        if (!decision.pass) {
          queue.set(wallet, { ...entry, status: 'rejected', aiReason: decision.reason })
          return
        }

        const txHash = await verifyOnChain(wallet, decision.level)
        queue.set(wallet, { ...entry, status: 'approved', txHash, aiReason: decision.reason })
      } catch (err) {
        console.error(`[KYC] Error for ${wallet}:`, err)
        entry = queue.get(wallet)!
        queue.set(wallet, { ...entry, status: 'pending', aiReason: 'Verification error — queued for manual review.' })
      }
    })()

    // Respond immediately; frontend polls /kyc/status/:addr
    sendJson(res, 200, {
      ok: true,
      status: 'processing',
      message: 'Document received. AI verification running — your status will update in seconds.',
    }); return
  }

  // GET /kyc/requests — admin queue
  if (req.method === 'GET' && req.url === '/kyc/requests') {
    const requests = [...queue.values()].sort((a, b) => {
      const order: Record<string, number> = { pending: 0, processing: 1, approved: 2, rejected: 3 }
      const diff = (order[a.status] ?? 4) - (order[b.status] ?? 4)
      return diff !== 0 ? diff : b.submittedAt - a.submittedAt
    })
    sendJson(res, 200, { ok: true, requests }); return
  }

  // POST /kyc/resolve — manual override
  if (req.method === 'POST' && req.url === '/kyc/resolve') {
    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }
    let payload: { wallet?: string; status?: string; txHash?: string }
    try { payload = JSON.parse(body.toString()) as typeof payload }
    catch { sendJson(res, 400, { error: 'Invalid JSON' }); return }
    const { wallet, status, txHash } = payload
    if (!wallet || !status) { sendJson(res, 400, { error: 'Missing wallet or status' }); return }
    const key = wallet.toLowerCase()
    const existing = queue.get(key)
    if (!existing) { sendJson(res, 404, { error: 'Request not found' }); return }
    queue.set(key, { ...existing, status: status as KycRequest['status'], txHash })
    console.log(`[KYC] Manual override: ${key} → ${status}`)
    sendJson(res, 200, { ok: true }); return
  }

  // GET /kyc/status/:addr — poll for AI result
  const sm = req.method === 'GET' && req.url?.match(/^\/kyc\/status\/(0x[0-9a-fA-F]{40})$/)
  if (sm) {
    const entry = queue.get(sm[1].toLowerCase())
    sendJson(res, 200, {
      ok:       true,
      status:   entry?.status ?? 'not_submitted',
      txHash:   entry?.txHash,
      aiReason: entry?.aiReason,
    }); return
  }

  // POST /kyc/tier1 — instant Level 1 verification from name + address + ID number
  if (req.method === 'POST' && req.url === '/kyc/tier1') {
    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }
    let payload: { wallet?: string; fullName?: string; address?: string; idNumber?: string }
    try { payload = JSON.parse(body.toString()) as typeof payload }
    catch { sendJson(res, 400, { error: 'Invalid JSON' }); return }

    const { wallet, fullName, address: addr, idNumber } = payload
    if (!wallet || !fullName?.trim() || !addr?.trim() || !idNumber?.trim()) {
      sendJson(res, 400, { error: 'wallet, fullName, address, and idNumber are all required' }); return
    }
    const walletKey = wallet.toLowerCase() as `0x${string}`
    if (!/^0x[0-9a-f]{40}$/.test(walletKey)) { sendJson(res, 400, { error: 'Invalid wallet address' }); return }

    // Already approved at level 1 or higher — no-op
    const existing = queue.get(walletKey)
    if (existing?.status === 'approved') {
      sendJson(res, 200, { ok: true, status: 'already_approved', txHash: existing.txHash }); return
    }

    // Mark as processing immediately
    queue.set(walletKey, { wallet: walletKey, docType: 'tier1_form', submittedAt: Date.now(), status: 'processing' })
    console.log(`[KYC Tier1] Processing: ${walletKey} (${fullName.trim()})`)

    // Fire-and-forget: verify on-chain at level 1
    void (async () => {
      try {
        const txHash = await verifyOnChain(walletKey, 1)
        queue.set(walletKey, { wallet: walletKey, docType: 'tier1_form', submittedAt: Date.now(), status: 'approved', txHash, aiReason: 'Tier 1 identity details verified.' })
        console.log(`[KYC Tier1] Approved: ${walletKey} → tx ${txHash}`)
      } catch (err) {
        console.error(`[KYC Tier1] On-chain error for ${walletKey}:`, err)
        queue.set(walletKey, { wallet: walletKey, docType: 'tier1_form', submittedAt: Date.now(), status: 'pending', aiReason: 'On-chain verification failed — queued for manual review.' })
      }
    })()

    // Respond immediately with processing status
    sendJson(res, 200, { ok: true, status: 'processing' }); return
  }

  // GET /kyc/tier1/status/:addr — poll for Tier 1 result (same as /kyc/status but named clearly)
  const t1sm = req.method === 'GET' && req.url?.match(/^\/kyc\/tier1\/status\/(0x[0-9a-fA-F]{40})$/)
  if (t1sm) {
    const entry = queue.get(t1sm[1].toLowerCase())
    sendJson(res, 200, { ok: true, status: entry?.status ?? 'not_submitted', txHash: entry?.txHash }); return
  }

  // POST /kyc/contact — user saves their public contact number
  if (req.method === 'POST' && req.url === '/kyc/contact') {
    const body = await readBody(req).catch(() => null)
    if (!body) { sendJson(res, 500, { error: 'Failed to read body' }); return }
    let payload: { wallet?: string; phone?: string }
    try { payload = JSON.parse(body.toString()) as typeof payload }
    catch { sendJson(res, 400, { error: 'Invalid JSON' }); return }
    const { wallet, phone } = payload
    if (!wallet) { sendJson(res, 400, { error: 'Missing wallet' }); return }
    const key = wallet.toLowerCase()
    if (!/^0x[0-9a-f]{40}$/.test(key)) { sendJson(res, 400, { error: 'Invalid wallet address' }); return }
    const trimmed = (phone ?? '').trim()
    if (trimmed) {
      contacts.set(key, { phone: trimmed, updatedAt: Date.now() })
    } else {
      contacts.delete(key)
    }
    sendJson(res, 200, { ok: true }); return
  }

  // GET /kyc/contact/:addr — anyone can fetch a wallet's public contact number
  const cm = req.method === 'GET' && req.url?.match(/^\/kyc\/contact\/(0x[0-9a-fA-F]{40})$/)
  if (cm) {
    const info = contacts.get(cm[1].toLowerCase())
    sendJson(res, 200, { ok: true, phone: info?.phone ?? null }); return
  }

  sendJson(res, 404, { error: 'Not found' })
}).listen(PORT, () => {
  console.log(`\n[KYC] Backend running on http://localhost:${PORT}`)
  console.log(`[KYC] Mode: AI AUTO-VERIFY — Claude vision → on-chain verifyUser`)
  console.log(`[KYC] AI:     ${ANTHROPIC_API_KEY ? 'configured' : 'MISSING (set ANTHROPIC_API_KEY)'}`)
  console.log(`[KYC] Signer: ${walletClient ? 'configured' : 'MISSING (set KYC_SIGNER_PRIVATE_KEY)'}`)
  console.log(`[KYC] Contract: ${CONTRACT_ADDRESS || 'MISSING (set VITE_CONTRACT_ADDRESS)'}`)
})
