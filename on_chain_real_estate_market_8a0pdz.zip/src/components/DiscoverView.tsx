import { useState, useEffect, useRef } from 'react'
import { useAccount, useWriteContract, useSwitchChain } from 'wagmi'
import { MapPin, Key, ArrowRight, Search, Building, Home, Warehouse, Loader2, Store, SlidersHorizontal } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { erc20Abi } from 'viem'
import {
  useListingCount, useListing, useUserProfile, formatUsdc,
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl, ListingData
} from '@/hooks/useRealEstateContract'
import { getUsdc } from '@/onchain-facts'
import KycBadge from './KycBadge'
import ReputationBar from './ReputationBar'
import { useTheme } from '@/ThemeContext'
import { Phone } from 'lucide-react'

// Fetch owner's public contact number from the backend
function useOwnerContact(ownerAddress: string | undefined) {
  const [phone, setPhone] = useState<string | null>(null)
  useEffect(() => {
    if (!ownerAddress) return
    void fetch(`/api/kyc/contact/${ownerAddress}`)
      .then(r => r.ok ? r.json() as Promise<{ phone?: string | null }> : null)
      .then(data => { if (data?.phone) setPhone(data.phone) })
      .catch(() => {})
  }, [ownerAddress])
  return phone
}

// ─── Hero slideshow ───────────────────────────────────────────────────────────

const HERO_SLIDES = [
  {
    url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1600&auto=format&fit=crop&q=80',
    caption: 'Modern Villa — Los Angeles, CA',
  },
  {
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1600&auto=format&fit=crop&q=80',
    caption: 'Luxury Residence — Miami Beach, FL',
  },
  {
    url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1600&auto=format&fit=crop&q=80',
    caption: 'Contemporary Home — Pacific Northwest',
  },
  {
    url: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=1600&auto=format&fit=crop&q=80',
    caption: 'Oceanfront Estate — Malibu, CA',
  },
  {
    url: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=1600&auto=format&fit=crop&q=80',
    caption: 'Classic Craftsman — Portland, OR',
  },
  {
    url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1600&auto=format&fit=crop&q=80',
    caption: 'Alpine Chalet — Aspen, CO',
  },
]

function HeroSlideshow({ children }: { children: React.ReactNode }) {
  const [current, setCurrent] = useState(0)
  const [prev, setPrev] = useState<number | null>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    timerRef.current = setTimeout(() => {
      setPrev(current)
      setCurrent(c => (c + 1) % HERO_SLIDES.length)
    }, 2000)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [current])

  return (
    <div className="relative h-[420px] sm:h-[520px] overflow-hidden">
      {/* Previous slide (fading out) */}
      {prev !== null && (
        <div
          key={`prev-${prev}`}
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_SLIDES[prev].url})`, opacity: 0, transition: 'opacity 0.9s ease' }}
        />
      )}
      {/* Current slide (fading in) */}
      <div
        key={`cur-${current}`}
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${HERO_SLIDES[current].url})`,
          animation: 'heroFadeIn 0.9s ease forwards',
        }}
      />
      {/* Dark overlay */}
      <div className="absolute inset-0" style={{ background: 'var(--hero-overlay)' }} />
      {/* Gradient to page bg */}
      <div className="absolute bottom-0 left-0 right-0 h-32" style={{ background: 'linear-gradient(to bottom, transparent, var(--bg-gradient))' }} />

      {/* Caption pill */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.4 }}
            className="rounded-full px-3 py-1 text-xs font-medium text-white/80 backdrop-blur-sm whitespace-nowrap"
            style={{ background: 'rgba(0,0,0,0.35)', border: '1px solid rgba(255,255,255,0.15)' }}
          >
            {HERO_SLIDES[current].caption}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Dot indicators */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
        {HERO_SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => { setPrev(current); setCurrent(i) }}
            className="rounded-full transition-all"
            style={{
              width: i === current ? 18 : 6,
              height: 6,
              background: i === current ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.35)',
            }}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>

      {/* Hero content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
        {children}
      </div>
    </div>
  )
}

// Extract cover image from metadataUri JSON if present
function getCoverImage(metadataUri: string): string | null {
  if (!metadataUri) return null
  try {
    const meta = JSON.parse(metadataUri) as Record<string, string>
    if (meta.image && (meta.image.startsWith('data:image') || meta.image.startsWith('http') || meta.image.startsWith('ipfs'))) {
      return meta.image
    }
  } catch { /* not JSON */ }
  // Plain URL
  if (metadataUri.startsWith('http') || metadataUri.startsWith('data:image')) return metadataUri
  return null
}

const propertyIcons: Record<string, React.ReactNode> = {
  apartment: <Building className="size-3.5" />,
  house: <Home className="size-3.5" />,
  commercial: <Warehouse className="size-3.5" />,
  retail: <Store className="size-3.5" />,
}

// ─── ListingCard ────────────────────────────────────────────────────────────

function ListingCard({ id, onAction }: { id: bigint; onAction: (listing: ListingData, mode: 'buy' | 'rent') => void }) {
  const { data: listing, refetch } = useListing(id)
  const { data: ownerProfile } = useUserProfile(listing?.owner)
  const { address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const [delisting, setDelisting] = useState(false)
  // Must be called unconditionally (Rules of Hooks) — hook handles undefined internally
  const ownerPhone = useOwnerContact(listing?.owner)

  if (!listing || !listing.active) return null

  const isOwner = address?.toLowerCase() === listing.owner?.toLowerCase()
  const ownerReputation = ownerProfile?.reputationScore ?? 250
  const ownerKyc = ownerProfile?.kycLevel ?? 0
  const coverImage = getCoverImage(listing.metadataUri)

  const accentColor = listing.forSale && listing.forRent
    ? 'linear-gradient(90deg, var(--accent) 50%, var(--success) 50%)'
    : listing.forSale ? 'var(--accent)' : 'var(--success)'

  const handleDelist = async () => {
    setDelisting(true)
    try {
      await writeContractAsync({
        address: REAL_ESTATE_ADDRESS,
        abi: REAL_ESTATE_ABI,
        functionName: 'updateListing',
        args: [listing.listingId, listing.priceUsdc, listing.rentPerMonthUsdc, listing.forSale, listing.forRent, false],
        chainId: CHAIN_ID,
      })
      await refetch()
    } catch { /* user rejected or error */ }
    finally { setDelisting(false) }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group rounded-2xl overflow-hidden flex flex-col"
      style={{
        background: 'var(--surface-card)',
        border: '1px solid var(--border)',
        boxShadow: 'var(--shadow-card)',
        transition: 'box-shadow 0.2s ease, border-color 0.2s ease, transform 0.2s ease',
      }}
      whileHover={{ y: -3, boxShadow: 'var(--shadow-hover)' }}
    >
      {/* Photo banner */}
      <div className="relative h-44 overflow-hidden" style={{ background: 'var(--surface-muted)' }}>
        {coverImage
          ? <img src={coverImage} alt={listing.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-2">
              <div className="flex size-12 items-center justify-center rounded-2xl" style={{ background: 'var(--border)' }}>
                {propertyIcons[listing.propertyType?.toLowerCase()] ?? <Building className="size-5" />}
              </div>
              <span className="text-xs font-medium capitalize" style={{ color: 'var(--subtle)' }}>{listing.propertyType}</span>
            </div>
          )
        }
        {/* Gradient overlay */}
        <div className="absolute inset-0" style={{ background: coverImage ? 'linear-gradient(to top, rgba(0,0,0,0.55) 0%, transparent 50%)' : 'none' }} />

        {/* Type badges */}
        <div className="absolute top-3 left-3 flex gap-1.5">
          {listing.forSale && (
            <span className="rounded-lg px-2 py-0.5 text-xs font-semibold text-white backdrop-blur-sm" style={{ background: 'rgba(18,45,69,0.75)' }}>
              For Sale
            </span>
          )}
          {listing.forRent && (
            <span className="rounded-lg px-2 py-0.5 text-xs font-semibold text-white backdrop-blur-sm" style={{ background: 'rgba(26,128,71,0.75)' }}>
              For Rent
            </span>
          )}
        </div>

        {/* Property type icon */}
        <div
          className="absolute top-3 right-3 flex size-7 items-center justify-center rounded-lg backdrop-blur-sm"
          style={{ background: 'rgba(255,255,255,0.18)', color: 'white' }}
        >
          {propertyIcons[listing.propertyType?.toLowerCase()] ?? <Building className="size-3.5" />}
        </div>

        {/* Price on photo */}
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
          <div className="flex flex-col gap-0.5">
            {listing.forSale && (
              <span className="display text-base font-bold text-white tabular-nums" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>
                {formatUsdc(listing.priceUsdc)} <span className="text-xs font-medium opacity-80">USDC</span>
              </span>
            )}
            {listing.forRent && (
              <span className="text-sm font-semibold text-white tabular-nums" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>
                {formatUsdc(listing.rentPerMonthUsdc)} <span className="text-xs font-medium opacity-80">USDC/mo</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Accent line */}
      <div className="h-0.5 shrink-0" style={{ background: accentColor }} />

      {/* Content */}
      <div className="p-4 flex flex-col gap-3 flex-1">
        {/* Title + location */}
        <div>
          <h3 className="display font-semibold text-sm leading-snug" style={{ color: 'var(--ink)' }}>{listing.title}</h3>
          <div className="flex items-center gap-1 mt-0.5">
            <MapPin className="size-3 shrink-0" style={{ color: 'var(--muted)' }} />
            <span className="text-xs truncate" style={{ color: 'var(--muted)' }}>{listing.location}</span>
          </div>
        </div>

        {/* Owner reputation row */}
        <div className="rounded-xl p-2.5" style={{ background: 'var(--surface-muted)' }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-medium" style={{ color: 'var(--muted)' }}>Owner reputation</span>
            <KycBadge level={ownerKyc} size="sm" />
          </div>
          <ReputationBar score={ownerReputation} showLabel={false} />
          <div className="mt-1 flex items-center justify-between">
            <span className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>{ownerReputation}/500 score</span>
            {ownerPhone && (
              <a href={`tel:${ownerPhone}`} className="flex items-center gap-1 text-xs font-medium rounded-lg px-2 py-0.5 transition-colors hover:bg-black/5"
                style={{ color: 'var(--accent)' }}>
                <Phone className="size-3" /> {ownerPhone}
              </a>
            )}
          </div>
        </div>

        {/* CTAs */}
        <div className="flex flex-col gap-2 mt-auto">
          <div className="flex gap-2">
            {listing.forSale && !isOwner && (
              <button
                onClick={() => onAction(listing, 'buy')}
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: 'var(--accent)', color: 'var(--bg)' }}
              >
                Buy Now <ArrowRight className="size-3" />
              </button>
            )}
            {listing.forRent && !isOwner && (
              <button
                onClick={() => onAction(listing, 'rent')}
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: 'var(--success-subtle)', color: 'var(--success)', border: '1px solid rgba(26,128,71,0.2)' }}
              >
                Rent <Key className="size-3" />
              </button>
            )}
          </div>
          {isOwner && (
            <button
              onClick={() => { void handleDelist() }}
              disabled={delisting}
              className="w-full flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-semibold transition-all hover:scale-[1.01] disabled:opacity-40"
              style={{ background: 'var(--danger-subtle)', color: 'var(--danger)', border: '1px solid rgba(186,43,76,0.2)' }}
            >
              {delisting ? <><Loader2 className="size-3 animate-spin" /> Delisting…</> : 'Delist Property'}
            </button>
          )}
          {isOwner && (
            <p className="text-[10px] text-center" style={{ color: 'var(--muted)' }}>Your listing — buyers see Buy/Rent buttons</p>
          )}
        </div>
      </div>
    </motion.div>
  )
}

function ListingCountLoader({ count, filter, onAction }: { count: number; filter: string; onAction: (listing: ListingData, mode: 'buy' | 'rent') => void }) {
  const ids = Array.from({ length: count }, (_, i) => BigInt(count - i))
  const filtered = filter === 'all' ? ids : ids // filter applied per-card via listing.forSale/forRent
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {filtered.map(id => <ListingCard key={id.toString()} id={id} onAction={onAction} />)}
    </div>
  )
}

// ─── ActionSheet ─────────────────────────────────────────────────────────────

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      <span className={`text-xs tabular-nums ${bold ? 'font-bold' : 'font-medium'}`} style={{ color: bold ? 'var(--ink)' : 'var(--ink-2)' }}>{value}</span>
    </div>
  )
}

// Escrow steps for purchase: INITIATE → APPROVE → FUND → INSPECT → COMPLETE
type BuyStep = 'initiate' | 'approve' | 'fund' | 'inspect' | 'complete' | 'done'
// Rent steps: INITIATE → APPROVE → DEPOSIT → DONE
type RentStep = 'initiate' | 'approve_deposit' | 'pay_deposit' | 'done'

const BUY_STEPS: { key: BuyStep; label: string }[] = [
  { key: 'initiate', label: 'Initiate' },
  { key: 'approve', label: 'Approve USDC' },
  { key: 'fund', label: 'Fund Escrow' },
  { key: 'inspect', label: 'Inspect' },
  { key: 'complete', label: 'Complete' },
]
const RENT_STEPS: { key: RentStep; label: string }[] = [
  { key: 'initiate', label: 'Initiate' },
  { key: 'approve_deposit', label: 'Approve USDC' },
  { key: 'pay_deposit', label: 'Pay Deposit' },
]

function StepBar({ steps, current }: { steps: { key: string; label: string }[]; current: string }) {
  const idx = steps.findIndex(s => s.key === current)
  return (
    <div className="flex items-center gap-0 mb-4">
      {steps.map((s, i) => (
        <div key={s.key} className="flex items-center flex-1">
          <div className="flex flex-col items-center flex-1">
            <div
              className="flex size-5 items-center justify-center rounded-full text-[10px] font-bold transition-all"
              style={{
                background: i <= idx ? 'var(--accent)' : 'var(--border)',
                color: i <= idx ? 'white' : 'var(--muted)',
              }}
            >
              {i < idx ? '✓' : i + 1}
            </div>
            <span className="text-[9px] mt-0.5 font-medium" style={{ color: i <= idx ? 'var(--ink)' : 'var(--muted)' }}>{s.label}</span>
          </div>
          {i < steps.length - 1 && (
            <div className="h-px flex-1 mb-3 mx-1 transition-all" style={{ background: i < idx ? 'var(--accent)' : 'var(--border)' }} />
          )}
        </div>
      ))}
    </div>
  )
}

function ActionSheet({ listing, mode, onClose }: { listing: ListingData; mode: 'buy' | 'rent'; onClose: () => void }) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContractAsync } = useWriteContract()
  const wrongChain = chainId !== CHAIN_ID

  const [buyStep, setBuyStep] = useState<BuyStep>('initiate')
  const [rentStep, setRentStep] = useState<RentStep>('initiate')
  const [escrowId, setEscrowId] = useState<bigint | null>(null)
  const [agreementId, setAgreementId] = useState<bigint | null>(null)
  const [busy, setBusy] = useState(false)
  const [lastHash, setLastHash] = useState<string | null>(null)
  const [txError, setTxError] = useState<string | null>(null)

  const usdcFact = getUsdc(CHAIN_ID)

  const cover = getCoverImage(listing.metadataUri)
  const purchaseTotal = listing.priceUsdc + (listing.priceUsdc * 150n / 10000n)
  const depositTotal = listing.rentPerMonthUsdc * 2n

  const switchIfNeeded = () => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return false }
    return true
  }

  const run = async (fn: () => Promise<`0x${string}`>, onSuccess: (hash: `0x${string}`) => void) => {
    if (!switchIfNeeded() || !address) return
    setTxError(null)
    setBusy(true)
    try {
      const hash = await fn()
      setLastHash(hash)
      onSuccess(hash)
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Transaction failed'
      setTxError(msg.length > 120 ? msg.slice(0, 120) + '…' : msg)
    } finally {
      setBusy(false)
    }
  }

  // ── BUY steps ──────────────────────────────────────────────
  const handleInitiatePurchase = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'initiatePurchase', args: [listing.listingId], chainId: CHAIN_ID }),
    () => setBuyStep('approve'),
  )

  const handleApproveUsdc = () => void run(
    () => writeContractAsync({ address: usdcFact!.address as `0x${string}`, abi: erc20Abi, functionName: 'approve', args: [REAL_ESTATE_ADDRESS, purchaseTotal], chainId: CHAIN_ID }),
    () => setBuyStep('fund'),
  )

  const handleFundEscrow = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'fundPurchaseEscrow', args: [escrowId ?? listing.listingId], chainId: CHAIN_ID }),
    () => setBuyStep('inspect'),
  )

  const handleConfirmInspection = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'confirmInspection', args: [escrowId ?? listing.listingId], chainId: CHAIN_ID }),
    () => setBuyStep('complete'),
  )

  const handleCompletePurchase = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'completePurchase', args: [escrowId ?? listing.listingId], chainId: CHAIN_ID }),
    () => setBuyStep('done'),
  )

  // ── RENT steps ─────────────────────────────────────────────
  const handleInitiateRent = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'initiateRent', args: [listing.listingId], chainId: CHAIN_ID }),
    () => setRentStep('approve_deposit'),
  )

  const handleApproveDeposit = () => void run(
    () => writeContractAsync({ address: usdcFact!.address as `0x${string}`, abi: erc20Abi, functionName: 'approve', args: [REAL_ESTATE_ADDRESS, depositTotal], chainId: CHAIN_ID }),
    () => setRentStep('pay_deposit'),
  )

  const handlePayDeposit = () => void run(
    () => writeContractAsync({ address: REAL_ESTATE_ADDRESS, abi: REAL_ESTATE_ABI, functionName: 'payDeposit', args: [agreementId ?? listing.listingId], chainId: CHAIN_ID }),
    () => setRentStep('done'),
  )

  const isDone = (mode === 'buy' && buyStep === 'done') || (mode === 'rent' && rentStep === 'done')

  if (isDone) {
    return (
      <div className="flex flex-col items-center gap-4 py-4 text-center">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 12 }}
          className="flex size-16 items-center justify-center rounded-2xl"
          style={{ background: 'var(--success-subtle)' }}
        >
          <span style={{ color: 'var(--success)', fontSize: 32 }}>✓</span>
        </motion.div>
        <div>
          <div className="font-bold display text-lg" style={{ color: 'var(--ink)' }}>
            {mode === 'buy' ? 'Purchase Complete!' : 'Deposit Paid!'}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
            {mode === 'buy' ? 'Funds released to seller. Transaction complete.' : 'Waiting for landlord to activate your rental.'}
          </div>
        </div>
        {lastHash && (
          <a href={getTxUrl(lastHash)} target="_blank" rel="noopener noreferrer" className="text-xs underline" style={{ color: 'var(--accent-hover)' }}>View on explorer</a>
        )}
        <button onClick={onClose} className="w-full rounded-2xl py-3.5 text-sm font-semibold transition-all hover:scale-[1.01]" style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
          Done
        </button>
      </div>
    )
  }

  // Escrow ID prompt: after initiate the buyer needs to enter the escrow/agreement ID
  // (the contract emits it; for now we provide an input if null)
  const needsId = mode === 'buy' && buyStep !== 'initiate' && escrowId === null
  const needsAgreementId = mode === 'rent' && rentStep !== 'initiate' && agreementId === null

  return (
    <div className="flex flex-col gap-4">
      {/* Property photo */}
      <div className="relative h-32 rounded-xl overflow-hidden" style={{ background: 'var(--surface-muted)' }}>
        {cover
          ? <img src={cover} alt={listing.title} className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center"><Building className="size-8" style={{ color: 'var(--border)' }} /></div>
        }
        {cover && <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.55) 0%, transparent 55%)' }} />}
        <div className="absolute bottom-2.5 left-3">
          <div className="font-bold display text-sm text-white" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{listing.title}</div>
          <div className="flex items-center gap-1 text-xs text-white/70 mt-0.5"><MapPin className="size-3" />{listing.location}</div>
        </div>
      </div>

      {/* Step bar */}
      {mode === 'buy'
        ? <StepBar steps={BUY_STEPS} current={buyStep} />
        : <StepBar steps={RENT_STEPS} current={rentStep} />
      }

      {/* ID input (needed after initiate) */}
      {(needsId || needsAgreementId) && (
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 block" style={{ color: 'var(--muted)' }}>
            {needsId ? 'Escrow ID (from transaction log)' : 'Agreement ID (from transaction log)'}
          </label>
          <input
            inputMode="numeric"
            placeholder="e.g. 1"
            className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
            style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
            onChange={e => {
              const v = BigInt(e.target.value || '0')
              if (needsId) setEscrowId(v > 0n ? v : null)
              else setAgreementId(v > 0n ? v : null)
            }}
          />
          <p className="text-[11px] mt-1" style={{ color: 'var(--muted)' }}>
            Check the explorer link from the previous step to find your ID.
          </p>
        </div>
      )}

      {/* Price breakdown */}
      <div className="rounded-2xl p-4 space-y-2" style={{ background: 'var(--surface-muted)' }}>
        {mode === 'buy' ? (
          <>
            <Row label="Purchase Price" value={`${formatUsdc(listing.priceUsdc)} USDC`} />
            <Row label="Platform Fee (1.5%)" value={`${formatUsdc(listing.priceUsdc * 150n / 10000n)} USDC`} />
            <div className="border-t pt-2" style={{ borderColor: 'var(--border)' }}>
              <Row label="Total into Escrow" value={`${formatUsdc(purchaseTotal)} USDC`} bold />
            </div>
          </>
        ) : (
          <>
            <Row label="Monthly Rent" value={`${formatUsdc(listing.rentPerMonthUsdc)} USDC`} />
            <Row label="Security Deposit (2×)" value={`${formatUsdc(depositTotal)} USDC`} bold />
          </>
        )}
      </div>

      {/* Step description */}
      <div className="rounded-xl px-3 py-2.5 text-xs leading-relaxed" style={{ background: 'var(--accent-subtle)', color: 'var(--ink-2)' }}>
        {mode === 'buy' && buyStep === 'initiate' && 'Step 1: Register your intent to purchase. No funds move yet.'}
        {mode === 'buy' && buyStep === 'approve' && 'Step 2: Approve the contract to spend your USDC. Required before funding.'}
        {mode === 'buy' && buyStep === 'fund' && 'Step 3: Lock USDC into escrow. Funds are held until you confirm inspection.'}
        {mode === 'buy' && buyStep === 'inspect' && 'Step 4: Confirm you have inspected the property and are satisfied.'}
        {mode === 'buy' && buyStep === 'complete' && 'Step 5: Release funds to the seller and complete the purchase.'}
        {mode === 'rent' && rentStep === 'initiate' && 'Step 1: Register your tenancy intent. No funds move yet.'}
        {mode === 'rent' && rentStep === 'approve_deposit' && 'Step 2: Approve the contract to take your 2-month security deposit.'}
        {mode === 'rent' && rentStep === 'pay_deposit' && 'Step 3: Lock deposit into escrow. Landlord will then activate the tenancy.'}
      </div>

      {/* Error */}
      {txError && (
        <div className="rounded-xl px-3 py-2 text-xs" style={{ background: 'var(--danger-subtle)', color: 'var(--danger)' }}>
          {txError}
        </div>
      )}

      {/* CTA button */}
      <button
        disabled={busy || !address || (needsId && escrowId === null) || (needsAgreementId && agreementId === null)}
        onClick={() => {
          if (mode === 'buy') {
            if (buyStep === 'initiate') handleInitiatePurchase()
            else if (buyStep === 'approve') handleApproveUsdc()
            else if (buyStep === 'fund') handleFundEscrow()
            else if (buyStep === 'inspect') handleConfirmInspection()
            else if (buyStep === 'complete') handleCompletePurchase()
          } else {
            if (rentStep === 'initiate') handleInitiateRent()
            else if (rentStep === 'approve_deposit') handleApproveDeposit()
            else if (rentStep === 'pay_deposit') handlePayDeposit()
          }
        }}
        className="w-full rounded-2xl py-3.5 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed"
        style={{ background: mode === 'buy' ? 'var(--accent)' : 'var(--success)', color: 'white' }}
      >
        {!address ? 'Connect Wallet'
          : wrongChain ? 'Switch to Arc Testnet'
          : busy ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirming…</span>
          : mode === 'buy' ? (
            { initiate: 'Initiate Purchase', approve: 'Approve USDC', fund: 'Fund Escrow', inspect: 'Confirm Inspection', complete: 'Complete Purchase', done: 'Done' }[buyStep]
          ) : (
            { initiate: 'Initiate Rental', approve_deposit: 'Approve USDC', pay_deposit: 'Pay Deposit', done: 'Done' }[rentStep]
          )
        }
      </button>
    </div>
  )
}

// ─── DiscoverView ─────────────────────────────────────────────────────────────

export default function DiscoverView() {
  const { data: countRaw } = useListingCount()
  const count = Number(countRaw ?? 0n)
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [actionListing, setActionListing] = useState<{ listing: ListingData; mode: 'buy' | 'rent' } | null>(null)
  const { theme } = useTheme()

  const filters = [
    { id: 'all', label: 'All' },
    { id: 'buy', label: 'For Sale' },
    { id: 'rent', label: 'For Rent' },
  ]

  return (
    <div>
      {/* ── Hero slideshow ───────────────────────────────────── */}
      <HeroSlideshow>
        <div className="text-center px-4 w-full max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <h1 className="display text-4xl sm:text-5xl font-bold text-white mb-3" style={{ letterSpacing: '-0.03em', textShadow: '0 2px 12px rgba(0,0,0,0.35)' }}>
              Real Estate,<br />On-Chain.
            </h1>
            <p className="text-white/75 text-base sm:text-lg max-w-md mx-auto" style={{ textShadow: '0 1px 6px rgba(0,0,0,0.4)' }}>
              KYC-verified listings. USDC escrow. Transparent reputation.
              No middlemen, no borders.
            </p>
          </motion.div>

          {/* Floating search bar */}
          <motion.div
            className="w-full mt-8"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div
              className="flex items-center gap-3 rounded-2xl px-4 py-3 backdrop-blur-xl"
              style={{ background: 'rgba(255,255,255,0.14)', border: '1px solid rgba(255,255,255,0.28)' }}
            >
              <Search className="size-4 shrink-0 text-white/70" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by city, country, or property type…"
                className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/50"
              />
              <button
                onClick={() => setShowFilters(f => !f)}
                className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold text-white/80 transition-all hover:text-white"
                style={{ background: showFilters ? 'rgba(255,255,255,0.2)' : 'transparent' }}
              >
                <SlidersHorizontal className="size-3.5" />
                Filters
              </button>
            </div>
          </motion.div>
        </div>
      </HeroSlideshow>

      {/* ── Stats bar ────────────────────────────────────────── */}
      <div className="border-b" style={{ borderColor: 'var(--border)', background: 'var(--surface-card)' }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="size-1.5 rounded-full" style={{ background: 'var(--success)' }} />
              <span className="text-xs font-medium tabular-nums" style={{ color: 'var(--muted)' }}>
                <span style={{ color: 'var(--ink)', fontWeight: 700 }}>{count}</span> active listing{count !== 1 ? 's' : ''}
              </span>
            </div>
            <div className="h-3 w-px" style={{ background: 'var(--border)' }} />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>All prices in USDC</span>
          </div>

          {/* Filter pills */}
          <div className="flex items-center gap-1 rounded-xl p-1" style={{ background: 'var(--surface-muted)' }}>
            {filters.map(f => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className="rounded-lg px-3 py-1 text-xs font-medium transition-all"
                style={{
                  background: filter === f.id ? 'var(--surface-card)' : 'transparent',
                  color: filter === f.id ? 'var(--ink)' : 'var(--muted)',
                  boxShadow: filter === f.id ? 'var(--shadow-card)' : 'none',
                }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Listings grid ────────────────────────────────────── */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {!REAL_ESTATE_ADDRESS ? (
          <EmptyState
            icon={<Building className="size-8" style={{ color: 'var(--muted)' }} />}
            title="Contract not deployed"
            sub="Deploy the RealEstate contract and set VITE_CONTRACT_ADDRESS to see live listings."
          />
        ) : count === 0 ? (
          <EmptyState
            icon={<Building className="size-8" style={{ color: 'var(--muted)' }} />}
            title="No listings yet"
            sub="Be the first to list a property on PropChain."
          />
        ) : (
          <ListingCountLoader
            count={count}
            filter={filter}
            onAction={(listing, mode) => setActionListing({ listing, mode })}
          />
        )}
      </div>

      {/* ── Action sheet overlay ─────────────────────────────── */}
      <AnimatePresence>
        {actionListing && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end justify-center"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setActionListing(null)}
          >
            <div className="absolute inset-0 backdrop-blur-sm" style={{ background: theme === 'dark' ? 'rgba(0,0,0,0.65)' : 'rgba(0,0,0,0.35)' }} />
            <motion.div
              className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
              style={{ background: 'var(--sheet-bg)' }}
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              onClick={e => e.stopPropagation()}
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-1">
                <div className="h-1 w-10 rounded-full" style={{ background: 'var(--border-strong)' }} />
              </div>
              <div className="px-5 pb-8 pt-2">
                <ActionSheet
                  listing={actionListing.listing}
                  mode={actionListing.mode}
                  onClose={() => setActionListing(null)}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function EmptyState({ icon, title, sub }: { icon: React.ReactNode; title: string; sub: string }) {
  return (
    <div
      className="rounded-2xl p-12 flex flex-col items-center text-center gap-3"
      style={{ background: 'var(--surface-muted)', border: '1px dashed var(--border-strong)' }}
    >
      {icon}
      <p className="font-semibold" style={{ color: 'var(--ink)' }}>{title}</p>
      <p className="text-sm max-w-xs text-pretty" style={{ color: 'var(--muted)' }}>{sub}</p>
    </div>
  )
}
