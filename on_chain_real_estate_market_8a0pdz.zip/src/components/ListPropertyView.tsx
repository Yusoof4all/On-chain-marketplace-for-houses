import { useState, useRef, useCallback } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { Loader2, CheckCircle2, Building, Home, Warehouse, Store, Upload, X, Image, FileText, Camera } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import { motion, AnimatePresence } from 'framer-motion'
import {
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl, parseUsdc
} from '@/hooks/useRealEstateContract'

const PROPERTY_TYPES = [
  { id: 'apartment', label: 'Apartment', icon: Building },
  { id: 'house', label: 'House', icon: Home },
  { id: 'commercial', label: 'Commercial', icon: Warehouse },
  { id: 'retail', label: 'Retail', icon: Store },
]

type ListingMode = 'sale' | 'rent' | 'lease'

const LISTING_MODES: { id: ListingMode; label: string; desc: string; color: string }[] = [
  { id: 'sale', label: 'For Sale', desc: 'One-time purchase with escrow', color: 'var(--accent)' },
  { id: 'rent', label: 'For Rent', desc: 'Monthly rolling tenancy', color: 'var(--success)' },
  { id: 'lease', label: 'Long Lease', desc: 'Fixed-term lease agreement', color: '#7c3aed' },
]

// ─── Image uploader ──────────────────────────────────────────────────────────

interface ImageSlot {
  file: File
  preview: string
}

function ImageUploader({ images, onAdd, onRemove }: {
  images: ImageSlot[]
  onAdd: (files: File[]) => void
  onRemove: (idx: number) => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files) return
    const accepted = Array.from(files)
      .filter(f => f.type.startsWith('image/'))
      .slice(0, 8 - images.length)
    onAdd(accepted)
  }, [images.length, onAdd])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>
        Property Photos <span style={{ color: 'var(--subtle)' }}>(up to 8, optional)</span>
      </label>

      {/* Thumbnails */}
      {images.length > 0 && (
        <div className="grid grid-cols-4 gap-2 mb-3">
          {images.map((img, i) => (
            <div key={i} className="relative rounded-xl overflow-hidden aspect-square group">
              <img src={img.preview} alt="" className="w-full h-full object-cover" />
              {i === 0 && (
                <div className="absolute bottom-0 inset-x-0 text-center py-0.5 text-[10px] font-semibold text-white" style={{ background: 'rgba(0,0,0,0.55)' }}>Cover</div>
              )}
              <button
                type="button"
                onClick={() => onRemove(i)}
                className="absolute top-1 right-1 flex size-5 items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background: 'rgba(0,0,0,0.6)' }}
              >
                <X className="size-3 text-white" />
              </button>
            </div>
          ))}
          {images.length < 8 && (
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="aspect-square rounded-xl border-2 border-dashed flex items-center justify-center transition-colors hover:border-opacity-60"
              style={{ borderColor: 'var(--border)' }}
            >
              <Camera className="size-5" style={{ color: 'var(--muted)' }} />
            </button>
          )}
        </div>
      )}

      {/* Drop zone — shown when no images */}
      {images.length === 0 && (
        <div
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className="cursor-pointer rounded-2xl border-2 border-dashed p-6 text-center transition-all"
          style={{
            borderColor: dragging ? 'var(--accent)' : 'var(--border)',
            background: dragging ? 'rgba(18,45,69,0.03)' : 'var(--surface-muted)',
          }}
        >
          <div className="flex flex-col items-center gap-2">
            <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.06)' }}>
              <Upload className="size-5" style={{ color: 'var(--muted)' }} />
            </div>
            <div>
              <div className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Drop photos here or click to browse</div>
              <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>JPEG, PNG, WebP · up to 8 photos</div>
            </div>
            <div className="flex gap-1.5">
              {[Image, FileText].map((Icon, i) => (
                <span key={i} className="flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs" style={{ background: 'var(--border)', color: 'var(--muted)' }}>
                  <Icon className="size-2.5" /> {i === 0 ? 'JPG/PNG' : 'WebP'}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="sr-only"
        onChange={e => handleFiles(e.target.files)}
      />

      <p className="text-xs mt-1.5" style={{ color: 'var(--subtle)' }}>
        Photos are stored as a data URI in the listing metadata. First photo is the cover image shown on discovery cards.
      </p>
    </div>
  )
}

// ─── Main component ──────────────────────────────────────────────────────────

export default function ListPropertyView() {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContract, data: hash, isPending, reset } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })

  const [mode, setMode] = useState<ListingMode>('sale')
  const [form, setForm] = useState({
    title: '',
    location: '',
    propertyType: 'apartment',
    priceUsdc: '',
    rentPerMonthUsdc: '',
    description: '',
  })
  const [images, setImages] = useState<ImageSlot[]>([])

  const wrongChain = chainId !== CHAIN_ID

  const handleAddImages = useCallback((files: File[]) => {
    const newSlots: ImageSlot[] = files.map(f => ({ file: f, preview: URL.createObjectURL(f) }))
    setImages(prev => [...prev, ...newSlots].slice(0, 8))
  }, [])

  const handleRemoveImage = useCallback((idx: number) => {
    setImages(prev => {
      const next = [...prev]
      URL.revokeObjectURL(next[idx].preview)
      next.splice(idx, 1)
      return next
    })
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    if (!address) return
    if (!form.title.trim() || !form.location.trim()) return

    const forSale = mode === 'sale'
    const forRent = mode === 'rent' || mode === 'lease'
    if (forSale && !form.priceUsdc) return
    if (forRent && !form.rentPerMonthUsdc) return

    // Build a compact metadata string: first image as data URI (if any) + description
    // This goes into metadataUri field — kept to ≤ 8KB for a single cover image thumbnail
    let metadataUri = ''
    if (images.length > 0 || form.description.trim()) {
      const meta: Record<string, string> = {}
      if (form.description.trim()) meta.description = form.description.trim()
      if (images.length > 0) meta.image = images[0].preview // object URL — backend/IPFS would replace this
      meta.mode = mode
      metadataUri = JSON.stringify(meta)
    }

    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: 'createListing',
      args: [
        form.title.trim(),
        form.location.trim(),
        form.propertyType,
        forSale && form.priceUsdc ? parseUsdc(form.priceUsdc) : 0n,
        forRent && form.rentPerMonthUsdc ? parseUsdc(form.rentPerMonthUsdc) : 0n,
        forSale,
        forRent,
        metadataUri,
      ],
      chainId: CHAIN_ID,
    })
  }

  const resetForm = () => {
    images.forEach(img => URL.revokeObjectURL(img.preview))
    setImages([])
    setForm({ title: '', location: '', propertyType: 'apartment', priceUsdc: '', rentPerMonthUsdc: '', description: '' })
    setMode('sale')
    reset()
  }

  if (isSuccess) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 flex flex-col items-center text-center gap-6">
        <div className="flex size-16 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.10)' }}>
          <CheckCircle2 className="size-8" style={{ color: 'var(--success)' }} />
        </div>
        <div>
          <h2 className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>Property Listed!</h2>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Your listing is live on-chain and visible in Discover.</p>
        </div>
        {hash && (
          <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-sm underline" style={{ color: 'var(--accent-hover)' }}>
            View transaction
          </a>
        )}
        <button onClick={resetForm} className="rounded-2xl px-8 py-3 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
          List Another Property
        </button>
      </div>
    )
  }

  const selectedMode = LISTING_MODES.find(m => m.id === mode)!

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="display text-2xl font-bold tracking-tight" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>List a Property</h1>
        <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Connect your wallet and list your property on-chain instantly.</p>
      </div>

      {!address ? (
        <div className="rounded-2xl p-8 flex flex-col items-center gap-4 text-center" style={{ background: 'var(--surface-muted)' }}>
          <Building className="size-8" style={{ color: 'var(--muted)' }} />
          <p style={{ color: 'var(--ink)' }} className="font-medium">Connect your wallet to list a property</p>
          <ConnectKitButton />
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">

          {/* ── Listing Mode ─────────────────────────────────────────────── */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>Listing Type</label>
            <div className="grid grid-cols-3 gap-2">
              {LISTING_MODES.map(m => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMode(m.id)}
                  className="relative flex flex-col items-start gap-1 rounded-2xl p-3 border-2 transition-all text-left"
                  style={{
                    borderColor: mode === m.id ? m.color : 'var(--border)',
                    background: mode === m.id ? `${m.color}12` : 'var(--surface-strong)',
                  }}
                >
                  <span className="text-sm font-bold" style={{ color: mode === m.id ? m.color : 'var(--ink)' }}>{m.label}</span>
                  <span className="text-[11px] leading-tight" style={{ color: 'var(--muted)' }}>{m.desc}</span>
                  {mode === m.id && (
                    <div className="absolute top-2 right-2 flex size-4 items-center justify-center rounded-full" style={{ background: m.color }}>
                      <CheckCircle2 className="size-3 text-white" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* ── Property Type ─────────────────────────────────────────────── */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: 'var(--muted)' }}>Property Type</label>
            <div className="grid grid-cols-4 gap-2">
              {PROPERTY_TYPES.map(pt => {
                const Icon = pt.icon
                return (
                  <button
                    key={pt.id}
                    type="button"
                    onClick={() => setForm(f => ({ ...f, propertyType: pt.id }))}
                    className="flex flex-col items-center gap-1.5 rounded-xl py-2.5 text-xs font-medium transition-all border"
                    style={{
                      background: form.propertyType === pt.id ? 'rgba(18,45,69,0.06)' : 'var(--surface-strong)',
                      color: form.propertyType === pt.id ? 'var(--ink)' : 'var(--muted)',
                      borderColor: form.propertyType === pt.id ? 'var(--accent)' : 'var(--border)',
                    }}
                  >
                    <Icon className="size-4" />
                    {pt.label}
                  </button>
                )
              })}
            </div>
          </div>

          {/* ── Photos ──────────────────────────────────────────────────── */}
          <ImageUploader images={images} onAdd={handleAddImages} onRemove={handleRemoveImage} />

          {/* ── Basic info ──────────────────────────────────────────────── */}
          <Field label="Property Title" required>
            <input
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Modern 2BR Apartment with Sea View"
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
              maxLength={120}
              required
            />
          </Field>

          <Field label="City, Country" required>
            <input
              value={form.location}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              placeholder="Dubai, UAE"
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
              required
            />
          </Field>

          <Field label="Description (optional)">
            <textarea
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Describe the property — rooms, amenities, condition…"
              className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border resize-none"
              style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
              rows={3}
              maxLength={500}
            />
          </Field>

          {/* ── Pricing ─────────────────────────────────────────────────── */}
          <AnimatePresence mode="wait">
            {mode === 'sale' && (
              <motion.div key="sale-price" initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}>
                <Field label="Sale Price (USDC)" required>
                  <PriceInput value={form.priceUsdc} onChange={v => setForm(f => ({ ...f, priceUsdc: v }))} suffix="USDC" placeholder="250,000.00" />
                </Field>
              </motion.div>
            )}
            {(mode === 'rent' || mode === 'lease') && (
              <motion.div key="rent-price" initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} className="space-y-4">
                <Field label={mode === 'lease' ? 'Monthly Lease Payment (USDC)' : 'Monthly Rent (USDC)'} required>
                  <PriceInput value={form.rentPerMonthUsdc} onChange={v => setForm(f => ({ ...f, rentPerMonthUsdc: v }))} suffix="/mo" placeholder="1,500.00" />
                </Field>
                {mode === 'lease' && (
                  <div className="rounded-xl px-3 py-2.5 text-xs flex items-start gap-2" style={{ background: 'rgba(124,58,237,0.07)', color: '#7c3aed', border: '1px solid rgba(124,58,237,0.15)' }}>
                    <span className="font-bold shrink-0 mt-0.5">Lease</span>
                    <span>A fixed-term lease locks in the monthly payment for the agreed duration. Tenants pay a 2-month deposit on activation, held in escrow.</span>
                  </div>
                )}
                {mode === 'rent' && (
                  <div className="rounded-xl px-3 py-2.5 text-xs" style={{ background: 'rgba(26,128,71,0.06)', color: 'var(--success)', border: '1px solid rgba(26,128,71,0.15)' }}>
                    Month-to-month tenancy. 2-month deposit held in escrow, returned on clean termination.
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── Summary note ────────────────────────────────────────────── */}
          <div className="rounded-xl p-3 text-xs space-y-0.5" style={{ background: `${selectedMode.color}0d`, color: 'var(--muted)', border: `1px solid ${selectedMode.color}20` }}>
            {mode === 'sale' && <p>• 1.5% platform fee on completed purchase</p>}
            {(mode === 'rent' || mode === 'lease') && <p>• 0.5% platform fee per monthly payment</p>}
            <p>• Listing stored on-chain, immutable and publicly visible</p>
            {images.length > 0 && <p>• {images.length} photo{images.length > 1 ? 's' : ''} attached — cover image shown in discovery</p>}
          </div>

          <button
            type="submit"
            disabled={!address || isPending || isConfirming}
            className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ background: selectedMode.color }}
          >
            {wrongChain ? 'Switch to Arc Testnet'
              : isPending ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirm in wallet…</span>
              : isConfirming ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Listing on-chain…</span>
              : `List as ${selectedMode.label}`}
          </button>
        </form>
      )}
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 block" style={{ color: 'var(--muted)' }}>
        {label}{required && <span style={{ color: 'var(--danger)' }}> *</span>}
      </label>
      {children}
    </div>
  )
}

function PriceInput({ value, onChange, suffix, placeholder }: { value: string; onChange: (v: string) => void; suffix: string; placeholder: string }) {
  return (
    <div className="relative">
      <input
        inputMode="decimal"
        value={value}
        onChange={e => onChange(e.target.value.replace(/[^0-9.]/g, ''))}
        placeholder={placeholder}
        className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border pr-16"
        style={{ background: 'var(--surface-strong)', color: 'var(--ink)', borderColor: 'var(--border)' }}
        required
      />
      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium" style={{ color: 'var(--muted)' }}>{suffix}</span>
    </div>
  )
}
