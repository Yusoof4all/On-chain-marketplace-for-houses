import { useState, useRef, useCallback, useEffect } from 'react'
import { useAccount } from 'wagmi'
import {
  Loader2, ShieldCheck, Upload, FileText, Image, X,
  CheckCircle2, AlertCircle, XCircle, User, MapPin, CreditCard,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'

// ─── Tier definitions ─────────────────────────────────────────────────────────

// Tier 1 — identity form, auto-verified immediately (no document needed)
// Tier 2 — document upload, AI-verified, upgrades to level 2

type DocType = 'passport' | 'national_id' | 'drivers_license' | 'residence_permit'

const DOC_TYPES: { value: DocType; label: string; description: string }[] = [
  { value: 'passport',         label: 'Passport',         description: 'International travel document' },
  { value: 'national_id',      label: 'National ID',       description: 'Government-issued identity card' },
  { value: 'drivers_license',  label: "Driver's License",  description: 'State or national driving permit' },
  { value: 'residence_permit', label: 'Residence Permit',  description: 'Official residency document' },
]

// ─── DropZone (Tier 2 only) ──────────────────────────────────────────────────

function DropZone({ file, onFile, onClear }: { file: File | null; onFile: (f: File) => void; onClear: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDragging(false)
    const f = e.dataTransfer.files[0]; if (f) onFile(f)
  }, [onFile])

  if (file) {
    const isImage = file.type.startsWith('image/')
    return (
      <div className="relative rounded-2xl border-2 overflow-hidden" style={{ borderColor: 'var(--success)', background: 'rgba(26,128,71,0.04)' }}>
        {isImage
          ? <img src={URL.createObjectURL(file)} alt="Document" className="w-full max-h-48 object-contain" />
          : (
            <div className="flex items-center gap-3 p-4">
              <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(26,128,71,0.1)' }}>
                <FileText className="size-5" style={{ color: 'var(--success)' }} />
              </div>
              <div>
                <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{file.name}</div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>{(file.size / 1024).toFixed(0)} KB · PDF</div>
              </div>
            </div>
          )
        }
        <button onClick={onClear} className="absolute top-2 right-2 flex size-6 items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.8)' }}>
          <X className="size-3.5" style={{ color: 'var(--ink-2)' }} />
        </button>
        <div className="px-3 py-1.5 text-xs font-medium" style={{ color: 'var(--success)', background: 'rgba(26,128,71,0.06)' }}>
          <CheckCircle2 className="inline size-3 mr-1" />Document ready
        </div>
      </div>
    )
  }

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className="cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all"
      style={{ borderColor: dragging ? 'var(--accent)' : 'var(--border)', background: dragging ? 'rgba(18,45,69,0.03)' : 'var(--surface-muted)' }}
    >
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="sr-only"
        onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }} />
      <div className="flex flex-col items-center gap-3">
        <div className="flex size-12 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.06)' }}>
          <Upload className="size-5" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Drop your document here</div>
          <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>or click to browse · JPEG, PNG, WebP, PDF · max 20 MB</div>
        </div>
        <div className="flex gap-2">
          {[['image/jpeg', 'JPG'], ['image/png', 'PNG'], ['application/pdf', 'PDF']].map(([t, lbl]) => (
            <span key={t} className="flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs font-medium" style={{ background: 'var(--border)', color: 'var(--muted)' }}>
              {t.startsWith('image') ? <Image className="size-2.5" /> : <FileText className="size-2.5" />} {lbl}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── KycFlow ──────────────────────────────────────────────────────────────────

type T1Step = 'form' | 'saving' | 'done' | 'error'
type T2Step = 'select_doc' | 'upload' | 'submitting' | 'processing' | 'done' | 'rejected' | 'error'

interface KycFlowProps {
  /** Current on-chain KYC level of the connected wallet (0, 1, or 2). */
  kycLevel: number
  onComplete?: () => void
}

export default function KycFlow({ kycLevel, onComplete }: KycFlowProps) {
  const { address } = useAccount()

  // Which tier tab is selected (users can always see both; only relevant tier is actionable)
  const [tier, setTier] = useState<1 | 2>(kycLevel >= 1 ? 2 : 1)

  // ── Tier 1 state ─────────────────────────────────────────────────
  const [t1Step, setT1Step] = useState<T1Step>('form')
  const [t1Form, setT1Form] = useState({ fullName: '', address: '', idNumber: '' })
  const [t1Error, setT1Error] = useState('')
  const [t1TxHash, setT1TxHash] = useState('')

  // Poll Tier 1 result after backend starts processing
  const t1PollRef = useRef<ReturnType<typeof setInterval> | null>(null)
  useEffect(() => {
    if (t1Step !== 'saving' || !address) return
    // start polling after a short delay so backend has time to start the tx
    const poll = async () => {
      try {
        const res = await fetch(`/api/kyc/tier1/status/${address}`)
        const data = await res.json() as { ok?: boolean; status?: string; txHash?: string }
        if (data.status === 'approved') {
          if (t1PollRef.current) { clearInterval(t1PollRef.current); t1PollRef.current = null }
          setT1TxHash(data.txHash ?? '')
          setT1Step('done')
          toast.success('Tier 1 KYC verified! You can now transact on PropChain.')
          onComplete?.()
        } else if (data.status === 'rejected' || data.status === 'not_submitted') {
          if (t1PollRef.current) { clearInterval(t1PollRef.current); t1PollRef.current = null }
          setT1Error('Verification failed — please try again.')
          setT1Step('error')
        }
        // 'processing' or 'pending' → keep polling
      } catch { /* network hiccup */ }
    }
    t1PollRef.current = setInterval(() => { void poll() }, 2000)
    return () => { if (t1PollRef.current) { clearInterval(t1PollRef.current); t1PollRef.current = null } }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [t1Step, address])

  const handleT1Submit = async () => {
    if (!address) return
    const { fullName, address: addr, idNumber } = t1Form
    if (!fullName.trim() || !addr.trim() || !idNumber.trim()) {
      setT1Error('All three fields are required.'); return
    }
    setT1Error('')
    try {
      const res = await fetch('/api/kyc/tier1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wallet: address, fullName: fullName.trim(), address: addr.trim(), idNumber: idNumber.trim() }),
      })
      const data = await res.json() as { ok?: boolean; status?: string; txHash?: string; error?: string }
      if (!res.ok || !data.ok) { setT1Error(data.error ?? 'Verification failed.'); return }
      if (data.status === 'already_approved') {
        setT1TxHash(data.txHash ?? ''); setT1Step('done')
        toast.success('Already verified at Tier 1!'); onComplete?.(); return
      }
      // Backend is processing — start polling
      setT1Step('saving')
    } catch {
      setT1Error('Network error — is the KYC server running?')
    }
  }

  // ── Tier 2 state ─────────────────────────────────────────────────
  const [t2Step, setT2Step] = useState<T2Step>('select_doc')
  const [docType, setDocType] = useState<DocType | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [t2Error, setT2Error] = useState('')
  const [aiReason, setAiReason] = useState('')
  const [t2TxHash, setT2TxHash] = useState('')
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (t2Step !== 'processing' || !address) return
    const poll = async () => {
      try {
        const res = await fetch(`/api/kyc/status/${address}`)
        const data = await res.json() as { ok?: boolean; status?: string; txHash?: string; aiReason?: string }
        if (data.status === 'approved') {
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
          setT2TxHash(data.txHash ?? '')
          setAiReason(data.aiReason ?? '')
          setT2Step('done')
          toast.success('Tier 2 KYC verified! Your reputation score is enhanced.')
          onComplete?.()
        } else if (data.status === 'rejected') {
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
          setAiReason(data.aiReason ?? 'Document did not pass verification.')
          setT2Step('rejected')
        }
      } catch { /* keep polling */ }
    }
    pollRef.current = setInterval(() => { void poll() }, 2000)
    void poll()
    return () => { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null } }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [t2Step, address])

  const handleT2Submit = async () => {
    if (!file || !docType || !address) return
    setT2Step('submitting'); setT2Error('')
    const formData = new FormData()
    formData.append('wallet', address)
    formData.append('docType', docType)
    formData.append('document', file)
    try {
      const res = await fetch('/api/kyc/submit', { method: 'POST', body: formData })
      const data = await res.json() as { ok?: boolean; error?: string; status?: string }
      if (!res.ok || !data.ok) { setT2Error(data.error ?? 'Submission failed.'); setT2Step('error'); return }
      if (data.status === 'already_approved') { toast.success('Already verified at Tier 2!'); onComplete?.(); return }
      setT2Step('processing')
    } catch {
      setT2Error('Network error — is the KYC server running?')
      setT2Step('error')
    }
  }

  // ── Tier labels ───────────────────────────────────────────────────
  const tier1Done = kycLevel >= 1 || t1Step === 'done'
  const tier2Done = kycLevel >= 2 || t2Step === 'done'

  return (
    <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
      {/* Header */}
      <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
            <ShieldCheck className="size-4" style={{ color: 'var(--accent)' }} />
          </div>
          <div>
            <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Identity Verification</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>
              Tier 1 unlocks buying &amp; renting · Tier 2 boosts your reputation score
            </div>
          </div>
        </div>
      </div>

      {/* Tier tabs */}
      <div className="flex border-b" style={{ borderColor: 'var(--border)' }}>
        {([1, 2] as const).map(t => {
          const done = t === 1 ? tier1Done : tier2Done
          const active = tier === t
          return (
            <button
              key={t}
              onClick={() => setTier(t)}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold transition-colors"
              style={{
                color: active ? 'var(--ink)' : 'var(--muted)',
                borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
                background: 'transparent',
              }}
            >
              {done
                ? <CheckCircle2 className="size-3.5" style={{ color: 'var(--success)' }} />
                : <span className="flex size-4 items-center justify-center rounded-full text-[10px] font-bold"
                    style={{ background: active ? 'var(--accent)' : 'var(--border)', color: active ? 'white' : 'var(--muted)' }}>{t}</span>
              }
              Tier {t} {t === 1 ? '— Basic' : '— Enhanced'}
              {done && <span className="text-[10px] font-medium" style={{ color: 'var(--success)' }}>✓</span>}
            </button>
          )
        })}
      </div>

      <div className="p-5">
        <AnimatePresence mode="wait">

          {/* ── TIER 1 ── */}
          {tier === 1 && (
            <motion.div key="t1" initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }}>

              {tier1Done ? (
                <div className="py-6 flex flex-col items-center gap-3 text-center">
                  <div className="flex size-14 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.1)' }}>
                    <CheckCircle2 className="size-8" style={{ color: 'var(--success)' }} />
                  </div>
                  <div>
                    <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Tier 1 Complete</div>
                    <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                      You are verified at Level 1. Upgrade to Tier 2 for an enhanced reputation score.
                    </div>
                  </div>
                  {t1TxHash && (
                    <a href={`https://explorer.testnet.arc.io/tx/${t1TxHash}`} target="_blank" rel="noopener noreferrer"
                      className="text-xs underline" style={{ color: 'var(--accent-hover)' }}>
                      View on-chain confirmation
                    </a>
                  )}
                  <button onClick={() => setTier(2)}
                    className="mt-1 rounded-2xl px-5 py-2.5 text-sm font-semibold text-white"
                    style={{ background: 'var(--accent)' }}>
                    Upgrade to Tier 2
                  </button>
                </div>
              ) : t1Step === 'saving' ? (
                <div className="py-8 flex flex-col items-center gap-4 text-center">
                  <Loader2 className="size-8 animate-spin" style={{ color: 'var(--accent)' }} />
                  <div className="font-semibold" style={{ color: 'var(--ink)' }}>Verifying on-chain…</div>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                    Enter your details exactly as they appear on your government ID.
                    Your information is stored securely and not published on-chain.
                  </p>

                  {/* Full name */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                      <User className="size-3" /> Full Legal Name
                    </label>
                    <input
                      value={t1Form.fullName}
                      onChange={e => setT1Form(f => ({ ...f, fullName: e.target.value }))}
                      placeholder="e.g. John Michael Doe"
                      className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink)', borderColor: 'var(--border)' }}
                    />
                  </div>

                  {/* Address */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                      <MapPin className="size-3" /> Residential Address
                    </label>
                    <input
                      value={t1Form.address}
                      onChange={e => setT1Form(f => ({ ...f, address: e.target.value }))}
                      placeholder="e.g. 123 Main Street, City, Country"
                      className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink)', borderColor: 'var(--border)' }}
                    />
                  </div>

                  {/* ID number */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest mb-1.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                      <CreditCard className="size-3" /> ID / Passport Number
                    </label>
                    <input
                      value={t1Form.idNumber}
                      onChange={e => setT1Form(f => ({ ...f, idNumber: e.target.value }))}
                      placeholder="e.g. AB123456"
                      className="w-full rounded-xl px-3 py-2.5 text-sm outline-none border mono"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink)', borderColor: 'var(--border)' }}
                    />
                  </div>

                  {(t1Step === 'error' || t1Error) && (
                    <div className="flex items-start gap-2 rounded-xl px-3 py-2.5 text-xs" style={{ background: 'rgba(186,43,76,0.06)', color: 'var(--danger)', border: '1px solid rgba(186,43,76,0.15)' }}>
                      <AlertCircle className="size-3.5 shrink-0 mt-0.5" />
                      {t1Error}
                    </div>
                  )}

                  <div className="rounded-xl px-3 py-2 text-xs" style={{ background: 'rgba(18,45,69,0.04)', color: 'var(--muted)' }}>
                    Your details are validated server-side and used only to confirm your identity. They are never published on-chain or shared with third parties.
                  </div>

                  <button
                    onClick={() => { void handleT1Submit() }}
                    disabled={!t1Form.fullName || !t1Form.address || !t1Form.idNumber}
                    className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{ background: 'var(--accent)' }}
                  >
                    <ShieldCheck className="size-4" /> Verify My Identity
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* ── TIER 2 ── */}
          {tier === 2 && (
            <motion.div key="t2" initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }}>

              {tier2Done ? (
                <div className="py-6 flex flex-col items-center gap-3 text-center">
                  <div className="flex size-14 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.1)' }}>
                    <CheckCircle2 className="size-8" style={{ color: 'var(--success)' }} />
                  </div>
                  <div>
                    <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Tier 2 Complete</div>
                    <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                      Full verification done. Your reputation score is enhanced.
                    </div>
                  </div>
                  {t2TxHash && (
                    <a href={`https://explorer.testnet.arc.io/tx/${t2TxHash}`} target="_blank" rel="noopener noreferrer"
                      className="text-xs underline" style={{ color: 'var(--accent-hover)' }}>
                      View on-chain confirmation
                    </a>
                  )}
                </div>
              ) : !tier1Done ? (
                <div className="py-6 flex flex-col items-center gap-3 text-center">
                  <div className="flex size-12 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.06)' }}>
                    <ShieldCheck className="size-6" style={{ color: 'var(--muted)' }} />
                  </div>
                  <div>
                    <div className="font-semibold" style={{ color: 'var(--ink)' }}>Complete Tier 1 first</div>
                    <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                      You need to complete Tier 1 identity verification before uploading a document for Tier 2.
                    </div>
                  </div>
                  <button onClick={() => setTier(1)}
                    className="rounded-2xl px-5 py-2.5 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
                    Go to Tier 1
                  </button>
                </div>
              ) : t2Step === 'select_doc' ? (
                <div className="space-y-3">
                  <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                    Upload a government-issued photo ID. Our AI reads it in seconds and upgrades your reputation score.
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {DOC_TYPES.map(dt => (
                      <button key={dt.value} onClick={() => setDocType(dt.value)}
                        className="text-left rounded-xl p-3 border-2 transition-all"
                        style={{ borderColor: docType === dt.value ? 'var(--accent)' : 'var(--border)', background: docType === dt.value ? 'rgba(18,45,69,0.04)' : 'var(--surface-muted)' }}>
                        <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{dt.label}</div>
                        <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{dt.description}</div>
                      </button>
                    ))}
                  </div>
                  <button disabled={!docType} onClick={() => setT2Step('upload')}
                    className="w-full rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{ background: 'var(--accent)' }}>
                    Continue
                  </button>
                </div>
              ) : t2Step === 'upload' ? (
                <div className="space-y-4">
                  <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                    Upload a clear photo of your <strong>{DOC_TYPES.find(d => d.value === docType)?.label}</strong>.
                  </p>
                  <DropZone file={file} onFile={setFile} onClear={() => setFile(null)} />
                  <div className="flex gap-2">
                    <button onClick={() => setT2Step('select_doc')} className="rounded-2xl px-4 py-3 text-sm font-medium" style={{ color: 'var(--ink-2)' }}>Back</button>
                    <button disabled={!file} onClick={() => { void handleT2Submit() }}
                      className="flex-1 flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                      style={{ background: 'var(--accent)' }}>
                      <ShieldCheck className="size-4" /> Submit for AI Review
                    </button>
                  </div>
                </div>
              ) : t2Step === 'submitting' ? (
                <div className="py-8 flex flex-col items-center gap-4 text-center">
                  <Loader2 className="size-8 animate-spin" style={{ color: 'var(--accent)' }} />
                  <div className="font-semibold" style={{ color: 'var(--ink)' }}>Uploading…</div>
                </div>
              ) : t2Step === 'processing' ? (
                <div className="py-8 flex flex-col items-center gap-4 text-center">
                  <div className="relative flex size-16 items-center justify-center rounded-full" style={{ background: 'rgba(18,45,69,0.07)' }}>
                    <ShieldCheck className="size-8" style={{ color: 'var(--accent)' }} />
                    <span className="absolute inset-0 rounded-full border-2 animate-spin" style={{ borderColor: 'var(--accent)', borderTopColor: 'transparent' }} />
                  </div>
                  <div>
                    <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>AI Review in Progress</div>
                    <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Reading your document — usually 5–15 seconds.</div>
                  </div>
                  <div className="flex gap-1.5">
                    {[0, 1, 2].map(i => (
                      <span key={i} className="size-1.5 rounded-full animate-pulse" style={{ background: 'var(--accent)', animationDelay: `${i * 0.2}s` }} />
                    ))}
                  </div>
                </div>
              ) : t2Step === 'rejected' ? (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-3 py-4 text-center">
                    <div className="flex size-14 items-center justify-center rounded-full" style={{ background: 'rgba(186,43,76,0.08)' }}>
                      <XCircle className="size-8" style={{ color: 'var(--danger)' }} />
                    </div>
                    <div>
                      <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Verification Failed</div>
                      <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>{aiReason || 'Document could not be verified. Try a clearer photo.'}</div>
                    </div>
                  </div>
                  <button onClick={() => { setT2Step('upload'); setFile(null); setAiReason('') }}
                    className="w-full rounded-2xl py-3 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
                    Try Again
                  </button>
                </div>
              ) : t2Step === 'error' ? (
                <div className="space-y-4">
                  <div className="flex items-start gap-3 rounded-xl p-3.5" style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)' }}>
                    <AlertCircle className="size-5 shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                    <div>
                      <div className="text-sm font-semibold" style={{ color: 'var(--danger)' }}>Submission failed</div>
                      <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{t2Error}</div>
                    </div>
                  </div>
                  <button onClick={() => { setT2Step('upload'); setFile(null); setT2Error('') }}
                    className="w-full rounded-2xl py-3 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
                    Try Again
                  </button>
                </div>
              ) : null}

            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}
